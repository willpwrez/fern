// Fern — allowlisted website preview proxy
// Only fetches domains you own or are authorized to access.
// Configure ALLOWED_HOSTS before starting the server.
const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const allowedHosts = (process.env.ALLOWED_HOSTS || "example.com")
  .split(",").map(s => s.trim().toLowerCase()).filter(Boolean);

app.use(express.static(path.join(__dirname, "public")));

app.get("/api/fetch", async (req, res) => {
  try {
    const raw = String(req.query.url || "");
    const target = new URL(raw);

    if (!["http:", "https:"].includes(target.protocol)) {
      return res.status(400).json({ error: "Only HTTP and HTTPS URLs are supported." });
    }
    if (target.username || target.password) {
      return res.status(400).json({ error: "URLs containing credentials are not allowed." });
    }

    const host = target.hostname.toLowerCase();
    const permitted = allowedHosts.some(domain => host === domain || host.endsWith("." + domain));
    if (!permitted) {
      return res.status(403).json({
        error: "This demo only previews domains on the server's ALLOWED_HOSTS list.",
        allowedHosts
      });
    }

    const upstream = await fetch(target, {
      redirect: "manual",
      headers: { "User-Agent": "FernAuthorizedPreview/1.0", "Accept": "text/html,text/plain" },
      signal: AbortSignal.timeout(10000)
    });

    if (upstream.status >= 300 && upstream.status < 400) {
      return res.status(400).json({ error: "Redirects are disabled in this starter. Open the approved destination directly." });
    }

    const contentType = upstream.headers.get("content-type") || "";
    if (!contentType.includes("text/html") && !contentType.includes("text/plain")) {
      return res.status(415).json({ error: "This starter previews HTML and plain text only." });
    }

    const body = await upstream.text();
    if (body.length > 1_000_000) {
      return res.status(413).json({ error: "Page is too large for this preview demo." });
    }

    res.json({
      title: target.hostname,
      url: target.href,
      contentType,
      html: contentType.includes("text/html")
        ? body
        : `<pre>${body.replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]))}</pre>`
    });
  } catch (err) {
    res.status(400).json({ error: "Could not load that page. Check the URL and try again." });
  }
});

app.listen(PORT, () => console.log(`Fern running at http://localhost:${PORT}`));
