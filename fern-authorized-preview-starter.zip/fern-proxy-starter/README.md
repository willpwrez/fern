# Fern authorized preview proxy

This is a small Node.js app that fetches and previews HTML/text from domains you own or are authorized to access. It is deliberately allowlisted; it is not a general-purpose proxy and cannot be used to evade network controls.

## Run locally
1. Install Node.js 18 or newer.
2. In this folder run: `npm install`
3. Set the approved domain list:
   - macOS/Linux: `ALLOWED_HOSTS=example.com,yourdomain.com npm start`
   - Windows PowerShell: `$env:ALLOWED_HOSTS="example.com,yourdomain.com"; npm start`
4. Open `http://localhost:3000`.

The default allowlist is `example.com`. Replace it with domains you control or have permission to test. Remote page JavaScript is disabled in the preview for safety; this starter supports HTML and plain text only.
